package com.rocketmq.service;

import com.alibaba.rocketmq.client.consumer.DefaultMQPullConsumer;
import com.alibaba.rocketmq.client.consumer.PullResult;
import com.alibaba.rocketmq.common.message.MessageQueue;
import com.alibaba.rocketmq.shade.com.alibaba.fastjson.JSONObject;
import com.rocketmq.entity.StatLog;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import com.alibaba.rocketmq.common.message.Message;
import com.alibaba.rocketmq.client.exception.MQClientException;
import com.alibaba.rocketmq.client.producer.DefaultMQProducer;
import com.alibaba.rocketmq.client.producer.SendCallback;
import com.alibaba.rocketmq.client.producer.SendResult;
import com.alibaba.rocketmq.client.producer.SendStatus;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;


public class MQServiceImpl {

    private static final Logger logger = LoggerFactory.getLogger(MQServiceImpl.class);

    private DefaultMQProducer producer = new DefaultMQProducer("producer");
    DefaultMQPullConsumer consumer = new DefaultMQPullConsumer("consumer");
    private static final Map<MessageQueue, Long> OFFSE_TABLE = new HashMap<MessageQueue, Long>();

    @Value("${rocketmq.url}")
    private String mqUrl = "";
    @Value("${mq_test_topic}")
    private String mqTopic = "";
    @Value("${rocketmq.tag}")
    private String mqTag = "";

    private SendCallback mqcallback;


    public boolean sendMsg(StatLog log) {
        try {
            Message msg = new Message(mqTopic, mqTag, JSONObject.toJSONString(log).getBytes());

            this.producer.send(msg, mqcallback);
            return true;
        } catch (Exception e) {
            logger.error("mq send failed e {}" + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }


    public String consumeMsg(StatLog log) {
        String result = "FAILURE";
        Set<MessageQueue> mqs = null;
        try {
            mqs = this.consumer.fetchSubscribeMessageQueues(mqTopic);
        } catch (MQClientException e) {
            e.printStackTrace();
        }
        for (MessageQueue mq : mqs) {
            System.out.printf("Consume from the queue: %s%n", mq);
            SINGLE_MQ:
            while (true) {
                try {
                    PullResult pullResult =
                            this.consumer.pullBlockIfNotFound(mq, null, getMessageQueueOffset(mq), 32);
                    System.out.printf("%s%n", pullResult);
                    putMessageQueueOffset(mq, pullResult.getNextBeginOffset());
                    switch (pullResult.getPullStatus()) {
                        case FOUND:
                            result="SUCCESS";
                            logger.info("msg:"+pullResult.getMsgFoundList().toString());
                            break;
                        case NO_MATCHED_MSG:
                            break;
                        case NO_NEW_MSG:
                            break SINGLE_MQ;
                        case OFFSET_ILLEGAL:
                            break;
                        default:
                            break;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return result;
    }


    @PostConstruct
    public void initProducer(){
        producer = new DefaultMQProducer("mq_test_producer");
        producer.setNamesrvAddr(mqUrl);
        try {
            producer.start();
        } catch (MQClientException e) {
            e.printStackTrace();
        }
        mqcallback = new MQCallbackImpl();
    }

    @PostConstruct
    public void initConsumer(){
        DefaultMQPullConsumer consumer = new DefaultMQPullConsumer("mq_test_consumer");
        consumer.setNamesrvAddr(mqUrl);
        try {
            consumer.start();
        } catch (MQClientException e) {
            e.printStackTrace();
        }
    }



    private class MQCallbackImpl implements SendCallback{

        @Override
        public void onSuccess(SendResult sendResult) {
            SendStatus status = sendResult.getSendStatus();
            if(status == SendStatus.SEND_OK){

            }else{
                logger.error("mq send failed rs {}" + JSONObject.toJSONString(sendResult));
            }
        }

        @Override
        public void onException(Throwable e) {
            e.printStackTrace();
            logger.error("mq send failed e {}" + e.getMessage());
        }

    }

    private static long getMessageQueueOffset(MessageQueue mq) {
        Long offset = OFFSE_TABLE.get(mq);
        if (offset != null)
            return offset;

        return 0;
    }

    private static void putMessageQueueOffset(MessageQueue mq, long offset) {
        OFFSE_TABLE.put(mq, offset);
    }
}

