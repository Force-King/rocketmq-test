package com.rocketmq.service;

import com.rocketmq.entity.StatLog;

public interface MQService {

    boolean sendMsg (StatLog log);

    String consumeMsg(StatLog log);
}
