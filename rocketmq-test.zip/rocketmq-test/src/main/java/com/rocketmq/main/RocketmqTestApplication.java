package com.rocketmq.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RocketmqTestApplication {

    public static void main(String[] args) {
        SpringApplication.run(RocketmqTestApplication.class, args);
    }

}

